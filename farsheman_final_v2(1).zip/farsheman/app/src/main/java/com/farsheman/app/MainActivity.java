package com.farsheman.app;

import android.app.*;import android.os.*;import android.Manifest;import android.content.pm.PackageManager;import android.webkit.*;import android.view.*;import android.widget.*;

public class MainActivity extends Activity{
 WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b); if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.CAMERA},7); web=new WebView(this); WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setMediaPlaybackRequiresUserGesture(false);web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient(){public boolean onShowFileChooser(WebView v,ValueCallback<android.net.Uri[]> cb,FileChooserParams p){Intent i=p.createIntent();try{startActivityForResult(i,9);}catch(Exception e){return false;}return true;}});web.loadUrl("file:///android_asset/index.html");setContentView(web);}
}
